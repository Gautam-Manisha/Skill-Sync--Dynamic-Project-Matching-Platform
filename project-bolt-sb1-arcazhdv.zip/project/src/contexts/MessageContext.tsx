import React, { createContext, useContext, useState, useEffect } from 'react';
import { Message } from '../types';

interface MessageContextType {
  messages: Message[];
  sendMessage: (message: Omit<Message, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (messageId: string) => void;
  getConversation: (userId1: string, userId2: string, projectId?: string) => Message[];
  getUnreadCount: (userId: string) => number;
}

const MessageContext = createContext<MessageContextType | undefined>(undefined);

export function MessageProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([]);

  useEffect(() => {
    const storedMessages = localStorage.getItem('skillsync_messages');
    if (storedMessages) {
      setMessages(JSON.parse(storedMessages));
    }
  }, []);

  const sendMessage = (messageData: Omit<Message, 'id' | 'timestamp' | 'read'>) => {
    const newMessage: Message = {
      ...messageData,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false,
    };

    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);
    localStorage.setItem('skillsync_messages', JSON.stringify(updatedMessages));
  };

  const markAsRead = (messageId: string) => {
    const updatedMessages = messages.map(msg =>
      msg.id === messageId ? { ...msg, read: true } : msg
    );
    setMessages(updatedMessages);
    localStorage.setItem('skillsync_messages', JSON.stringify(updatedMessages));
  };

  const getConversation = (userId1: string, userId2: string, projectId?: string) => {
    return messages
      .filter(msg => 
        ((msg.from === userId1 && msg.to === userId2) || 
         (msg.from === userId2 && msg.to === userId1)) &&
        (!projectId || msg.projectId === projectId)
      )
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  };

  const getUnreadCount = (userId: string) => {
    return messages.filter(msg => msg.to === userId && !msg.read).length;
  };

  return (
    <MessageContext.Provider value={{
      messages,
      sendMessage,
      markAsRead,
      getConversation,
      getUnreadCount,
    }}>
      {children}
    </MessageContext.Provider>
  );
}

export function useMessages() {
  const context = useContext(MessageContext);
  if (context === undefined) {
    throw new Error('useMessages must be used within a MessageProvider');
  }
  return context;
}