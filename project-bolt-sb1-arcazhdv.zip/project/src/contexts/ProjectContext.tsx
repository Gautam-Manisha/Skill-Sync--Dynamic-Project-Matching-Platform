import React, { createContext, useContext, useState, useEffect } from 'react';
import { Project, User } from '../types';

interface ProjectContextType {
  projects: Project[];
  createProject: (project: Omit<Project, 'id' | 'createdAt' | 'status' | 'members'>) => void;
  joinProject: (projectId: string, userId: string) => void;
  getUserProjects: (userId: string) => Project[];
  getProjectMatches: (user: User) => Project[];
}

const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

export function ProjectProvider({ children }: { children: React.ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    // Load projects from localStorage
    const storedProjects = localStorage.getItem('skillsync_projects');
    if (storedProjects) {
      setProjects(JSON.parse(storedProjects));
    } else {
      // Initialize with sample projects
      const sampleProjects: Project[] = [
        {
          id: '1',
          title: 'AI-Powered Study Assistant',
          description: 'Building an intelligent tutoring system that adapts to individual learning styles using machine learning algorithms.',
          techStack: ['React', 'Python', 'TensorFlow', 'Node.js'],
          requiredSkills: ['Machine Learning', 'Frontend Development', 'Python', 'React'],
          teamSize: 4,
          duration: '3 months',
          location: 'remote',
          domain: 'Artificial Intelligence',
          createdBy: 'sample-user-1',
          creatorName: 'Dr. Sarah Chen',
          status: 'open',
          members: [],
          createdAt: new Date('2024-01-15'),
          sector: 'academic'
        },
        {
          id: '2',
          title: 'Sustainable Campus App',
          description: 'Mobile application to track and reduce carbon footprint on university campuses with gamification elements.',
          techStack: ['React Native', 'Firebase', 'Node.js'],
          requiredSkills: ['Mobile Development', 'UI/UX Design', 'Backend Development'],
          teamSize: 3,
          duration: '2 months',
          location: 'hybrid',
          domain: 'Environmental Tech',
          createdBy: 'sample-user-2',
          creatorName: 'Alex Rivera',
          status: 'open',
          members: [],
          createdAt: new Date('2024-01-20'),
          sector: 'hackathon'
        }
      ];
      setProjects(sampleProjects);
      localStorage.setItem('skillsync_projects', JSON.stringify(sampleProjects));
    }
  }, []);

  const createProject = (projectData: Omit<Project, 'id' | 'createdAt' | 'status' | 'members'>) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString(),
      createdAt: new Date(),
      status: 'open',
      members: [projectData.createdBy],
    };

    const updatedProjects = [...projects, newProject];
    setProjects(updatedProjects);
    localStorage.setItem('skillsync_projects', JSON.stringify(updatedProjects));
  };

  const joinProject = (projectId: string, userId: string) => {
    const updatedProjects = projects.map(project => {
      if (project.id === projectId && !project.members.includes(userId)) {
        return {
          ...project,
          members: [...project.members, userId]
        };
      }
      return project;
    });

    setProjects(updatedProjects);
    localStorage.setItem('skillsync_projects', JSON.stringify(updatedProjects));
  };

  const getUserProjects = (userId: string) => {
    return projects.filter(project => 
      project.createdBy === userId || project.members.includes(userId)
    );
  };

  const getProjectMatches = (user: User): Project[] => {
    return projects
      .filter(project => 
        project.status === 'open' && 
        !project.members.includes(user.id) &&
        project.createdBy !== user.id
      )
      .map(project => {
        const skillMatch = project.requiredSkills.filter(skill => 
          user.skills.some(userSkill => 
            userSkill.toLowerCase().includes(skill.toLowerCase()) ||
            skill.toLowerCase().includes(userSkill.toLowerCase())
          )
        ).length;

        const interestMatch = user.interests.some(interest =>
          project.domain.toLowerCase().includes(interest.toLowerCase()) ||
          interest.toLowerCase().includes(project.domain.toLowerCase())
        );

        return {
          ...project,
          matchScore: skillMatch + (interestMatch ? 2 : 0)
        };
      })
      .sort((a: any, b: any) => b.matchScore - a.matchScore)
      .slice(0, 10);
  };

  return (
    <ProjectContext.Provider value={{
      projects,
      createProject,
      joinProject,
      getUserProjects,
      getProjectMatches,
    }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProjects() {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProjects must be used within a ProjectProvider');
  }
  return context;
}