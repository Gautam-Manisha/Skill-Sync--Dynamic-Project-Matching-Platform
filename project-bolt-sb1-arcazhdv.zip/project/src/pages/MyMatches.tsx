import React from 'react';
import { Target, Users, TrendingUp, Clock } from 'lucide-react';
import { useProjects } from '../contexts/ProjectContext';
import { useAuth } from '../contexts/AuthContext';

export default function MyMatches() {
  const { projects, getProjectMatches, joinProject } = useProjects();
  const { user } = useAuth();

  if (!user) return null;

  const matches = getProjectMatches(user);
  const userProjects = projects.filter(p => p.createdBy === user.id);

  const handleJoinProject = (projectId: string) => {
    joinProject(projectId, user.id);
  };

  const getMatchScore = (project: any) => {
    const skillMatches = project.requiredSkills.filter((skill: string) => 
      user.skills.some(userSkill => 
        userSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    );

    const interestMatch = user.interests.some(interest =>
      project.domain.toLowerCase().includes(interest.toLowerCase()) ||
      interest.toLowerCase().includes(project.domain.toLowerCase())
    );

    return {
      skillMatches,
      interestMatch,
      score: skillMatches.length + (interestMatch ? 2 : 0)
    };
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Your Matches</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Personalized project recommendations based on your skills and interests
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-blue-100 rounded-lg">
              <Target className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{matches.length}</p>
              <p className="text-sm text-gray-600">New Matches</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-teal-100 rounded-lg">
              <Users className="h-6 w-6 text-teal-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{userProjects.length}</p>
              <p className="text-sm text-gray-600">Your Projects</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-purple-100 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">
                {matches.length > 0 ? Math.round(matches.reduce((acc: number, p: any) => acc + getMatchScore(p).score, 0) / matches.length) : 0}%
              </p>
              <p className="text-sm text-gray-600">Avg Match Score</p>
            </div>
          </div>
        </div>
      </div>

      {/* Project Matches */}
      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900 mb-6">Recommended Projects</h2>
          
          {matches.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
              <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No matches found</h3>
              <p className="text-gray-600 mb-4">
                Update your profile with more skills and interests to get better matches
              </p>
              <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Update Profile
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {matches.map((project) => {
                const matchDetails = getMatchScore(project);
                const isUserInProject = project.members.includes(user.id) || project.createdBy === user.id;
                
                return (
                  <div key={project.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    {/* Match Score */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium text-green-700">
                          {matchDetails.score > 3 ? 'Excellent' : matchDetails.score > 1 ? 'Good' : 'Fair'} Match
                        </span>
                      </div>
                      <div className="flex items-center space-x-1 text-sm text-gray-500">
                        <TrendingUp className="h-4 w-4" />
                        <span>{Math.min(matchDetails.score * 20, 100)}% match</span>
                      </div>
                    </div>

                    {/* Project Info */}
                    <div className="mb-4">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{project.title}</h3>
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">{project.description}</p>
                      <p className="text-blue-600 text-sm font-medium">{project.domain}</p>
                    </div>

                    {/* Match Details */}
                    <div className="space-y-3 mb-4">
                      {matchDetails.skillMatches.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-gray-700 mb-1">Matching Skills:</p>
                          <div className="flex flex-wrap gap-1">
                            {matchDetails.skillMatches.map((skill: string) => (
                              <span key={skill} className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {matchDetails.interestMatch && (
                        <div>
                          <p className="text-xs font-medium text-gray-700 mb-1">Interest Match:</p>
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                            {project.domain}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Project Details */}
                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span>{project.members.length}/{project.teamSize}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span>{project.duration}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action */}
                    <div className="pt-4 border-t border-gray-200">
                      {isUserInProject ? (
                        <button
                          disabled
                          className="w-full bg-gray-100 text-gray-500 py-2 px-4 rounded-lg font-medium cursor-not-allowed"
                        >
                          {project.createdBy === user.id ? 'Your Project' : 'Already Joined'}
                        </button>
                      ) : project.members.length >= project.teamSize ? (
                        <button
                          disabled
                          className="w-full bg-gray-100 text-gray-500 py-2 px-4 rounded-lg font-medium cursor-not-allowed"
                        >
                          Team Full
                        </button>
                      ) : (
                        <button
                          onClick={() => handleJoinProject(project.id)}
                          className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                        >
                          Request to Join
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}