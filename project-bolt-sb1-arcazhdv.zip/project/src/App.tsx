import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import BrowseProjects from './pages/BrowseProjects';
import PostProject from './pages/PostProject';
import MyMatches from './pages/MyMatches';
import Messages from './pages/Messages';
import ProjectShowcase from './pages/ProjectShowcase';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ProjectProvider } from './contexts/ProjectContext';
import { MessageProvider } from './contexts/MessageContext';

function AppContent() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {user && <Navbar />}
      <Routes>
        <Route path="/login" element={!user ? <Login /> : <Navigate to="/" />} />
        <Route path="/register" element={!user ? <Register /> : <Navigate to="/" />} />
        
        {/* Protected Routes */}
        <Route path="/" element={user ? <Home /> : <Navigate to="/login" />} />
        <Route path="/profile" element={user ? <Profile /> : <Navigate to="/login" />} />
        <Route path="/browse-projects" element={user ? <BrowseProjects /> : <Navigate to="/login" />} />
        <Route path="/post-project" element={user ? <PostProject /> : <Navigate to="/login" />} />
        <Route path="/my-matches" element={user ? <MyMatches /> : <Navigate to="/login" />} />
        <Route path="/messages" element={user ? <Messages /> : <Navigate to="/login" />} />
        <Route path="/showcase" element={user ? <ProjectShowcase /> : <Navigate to="/login" />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <ProjectProvider>
          <MessageProvider>
            <AppContent />
          </MessageProvider>
        </ProjectProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;