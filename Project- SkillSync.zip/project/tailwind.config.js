/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'heading': ['Poppins', 'system-ui', 'sans-serif'],
      },
      colors: {
        primary: {
          50: '#faf8f5',
          100: '#f4f0e8',
          200: '#e8dcc6',
          300: '#d4c0a1',
          400: '#c4a882',
          500: '#b8956b',
          600: '#a67c52',
          700: '#8b6441',
          800: '#725238',
          900: '#5d4330',
        },
        accent: {
          50: '#fdf8f3',
          100: '#fbeee0',
          200: '#f6dcc0',
          300: '#efc195',
          400: '#e6a168',
          500: '#d4824a',
          600: '#c26d3f',
          700: '#a15536',
          800: '#824632',
          900: '#6b3b2b',
        },
        background: '#fdfcfa',
        text: '#2d2520',
      },
    },
  },
  plugins: [],
};