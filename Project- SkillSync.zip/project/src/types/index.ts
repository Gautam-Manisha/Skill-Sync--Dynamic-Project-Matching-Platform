export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'project_leader' | 'admin';
  university?: string;
  profilePicture?: string;
  skills: string[];
  interests: string[];
  experience?: string;
  portfolioLink?: string;
  createdAt: Date;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  techStack: string[];
  requiredSkills: string[];
  teamSize: number;
  duration: string;
  location: 'remote' | 'on-site' | 'hybrid';
  domain: string;
  createdBy: string;
  creatorName: string;
  status: 'open' | 'in-progress' | 'completed';
  members: string[];
  memberDetails?: User[];
  createdAt: Date;
  sector: 'academic' | 'hackathon' | 'government' | 'corporate';
}

export interface Message {
  id: string;
  from: string;
  to: string;
  projectId?: string;
  content: string;
  timestamp: Date;
  read: boolean;
}

export interface Match {
  id: string;
  userId: string;
  projectId: string;
  score: number;
  type: 'project_suggestion' | 'team_member_suggestion';
  status: 'pending' | 'accepted' | 'declined';
  createdAt: Date;
}