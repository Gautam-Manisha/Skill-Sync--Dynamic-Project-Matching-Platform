import React, { useState } from 'react';
import { Star, Users, Clock, ExternalLink, Filter } from 'lucide-react';
import { useProjects } from '../contexts/ProjectContext';

export default function ProjectShowcase() {
  const { projects } = useProjects();
  const [selectedDomain, setSelectedDomain] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  // Filter for completed and in-progress projects for showcase
  const showcaseProjects = projects.filter(p => p.status === 'completed' || p.status === 'in-progress');
  
  const domains = [...new Set(showcaseProjects.map(p => p.domain))];

  const filteredProjects = showcaseProjects.filter(project => {
    const matchesDomain = !selectedDomain || project.domain === selectedDomain;
    const matchesStatus = !selectedStatus || project.status === selectedStatus;
    return matchesDomain && matchesStatus;
  });

  // Mock rating data (in real app, this would come from a rating system)
  const getProjectRating = (projectId: string) => {
    const ratings = [4.5, 4.2, 4.8, 4.0, 4.7, 4.3, 4.6];
    return ratings[Math.floor(Math.random() * ratings.length)];
  };

  const getProjectViews = (projectId: string) => {
    return Math.floor(Math.random() * 1000) + 100;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Project Showcase</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Discover amazing projects built by our community of talented developers
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex items-center space-x-4">
          <Filter className="h-5 w-5 text-gray-400" />
          <select
            value={selectedDomain}
            onChange={(e) => setSelectedDomain(e.target.value)}
            className="p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Domains</option>
            {domains.map(domain => (
              <option key={domain} value={domain}>{domain}</option>
            ))}
          </select>
          
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">All Status</option>
            <option value="completed">Completed</option>
            <option value="in-progress">In Progress</option>
          </select>

          <div className="text-sm text-gray-600 ml-auto">
            Showing {filteredProjects.length} projects
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project) => {
          const rating = getProjectRating(project.id);
          const views = getProjectViews(project.id);
          
          return (
            <div key={project.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
              {/* Project Image Placeholder */}
              <div className="h-48 bg-gradient-to-br from-blue-50 to-teal-50 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-teal-500 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <span className="text-white font-bold text-xl">
                      {project.title.charAt(0)}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm">{project.domain}</p>
                </div>
              </div>

              <div className="p-6">
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{project.title}</h3>
                    <p className="text-sm text-gray-600">by {project.creatorName}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    project.status === 'completed' 
                      ? 'bg-green-100 text-green-700'
                      : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {project.status === 'completed' ? 'Completed' : 'In Progress'}
                  </span>
                </div>

                {/* Description */}
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">{project.description}</p>

                {/* Tech Stack */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {project.techStack.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.techStack.length > 3 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                        +{project.techStack.length - 3}
                      </span>
                    )}
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-1">
                      <Users className="h-4 w-4" />
                      <span>{project.members.length} members</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{project.duration}</span>
                    </div>
                  </div>
                </div>

                {/* Rating and Views */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">{rating.toFixed(1)}</span>
                    <span className="text-sm text-gray-500">({Math.floor(rating * 20)} reviews)</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    {views} views
                  </div>
                </div>

                {/* Action Button */}
                <button className="w-full flex items-center justify-center space-x-2 bg-gray-50 hover:bg-gray-100 text-gray-700 py-2 px-4 rounded-lg transition-colors">
                  <ExternalLink className="h-4 w-4" />
                  <span>View Project</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredProjects.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-400 mb-4">
            <Star className="h-12 w-12 mx-auto" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No projects found</h3>
          <p className="text-gray-600">Try adjusting your filters or check back later</p>
        </div>
      )}
    </div>
  );
}