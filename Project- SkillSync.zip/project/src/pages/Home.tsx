import React from 'react';
import { Link } from 'react-router-dom';
import { Target, Users, Zap, Award, ArrowRight, TrendingUp } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useProjects } from '../contexts/ProjectContext';

export default function Home() {
  const { user } = useAuth();
  const { projects, getUserProjects, getProjectMatches } = useProjects();

  const userProjects = user ? getUserProjects(user.id) : [];
  const matches = user ? getProjectMatches(user) : [];
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'open').length;

  const stats = [
    { label: 'Total Projects', value: totalProjects, icon: Target, color: 'text-amber-600' },
    { label: 'Active Projects', value: activeProjects, icon: TrendingUp, color: 'text-orange-600' },
    { label: 'Your Projects', value: userProjects.length, icon: Users, color: 'text-yellow-600' },
    { label: 'New Matches', value: matches.length, icon: Zap, color: 'text-orange-600' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
          Welcome back, <span className="text-amber-600">{user?.name}</span>!
        </h1>
        <p className="text-xl text-stone-600 max-w-3xl mx-auto">
          Discover amazing projects, connect with talented teammates, and build something extraordinary together.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {stats.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-stone-600">{label}</p>
                <p className="text-3xl font-bold text-stone-800">{value}</p>
              </div>
              <div className={`p-3 rounded-lg bg-stone-50`}>
                <Icon className={`h-6 w-6 ${color}`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        <Link
          to="/browse-projects"
          className="group bg-gradient-to-br from-amber-50 to-amber-100 rounded-xl p-6 hover:from-amber-100 hover:to-amber-200 transition-all duration-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-amber-600 rounded-lg">
              <Target className="h-6 w-6 text-white" />
            </div>
            <ArrowRight className="h-5 w-5 text-amber-600 group-hover:translate-x-1 transition-transform" />
          </div>
          <h3 className="text-lg font-semibold text-stone-800 mb-2">Browse Projects</h3>
          <p className="text-stone-600">Discover exciting projects looking for your skills</p>
        </Link>

        <Link
          to="/my-matches"
          className="group bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-6 hover:from-orange-100 hover:to-orange-200 transition-all duration-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-orange-600 rounded-lg">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <ArrowRight className="h-5 w-5 text-orange-600 group-hover:translate-x-1 transition-transform" />
          </div>
          <h3 className="text-lg font-semibold text-stone-800 mb-2">View Matches</h3>
          <p className="text-stone-600">See personalized project recommendations</p>
        </Link>

        <Link
          to="/post-project"
          className="group bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl p-6 hover:from-yellow-100 hover:to-yellow-200 transition-all duration-200"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 bg-yellow-600 rounded-lg">
              <Award className="h-6 w-6 text-white" />
            </div>
            <ArrowRight className="h-5 w-5 text-yellow-600 group-hover:translate-x-1 transition-transform" />
          </div>
          <h3 className="text-lg font-semibold text-stone-800 mb-2">Post Project</h3>
          <p className="text-stone-600">Share your idea and find collaborators</p>
        </Link>
      </div>

      {/* Recent Matches Preview */}
      {matches.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="bg-white rounded-xl shadow-sm border border-stone-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-stone-800">Recommended for You</h2>
            <Link
              to="/my-matches"
              className="text-amber-600 hover:text-amber-700 font-medium text-sm flex items-center space-x-1"
            >
              <span>View all</span>
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {matches.slice(0, 2).map((project) => (
              <div key={project.id} className="border border-stone-200 rounded-lg p-4">
                <h3 className="font-semibold text-stone-800 mb-2">{project.title}</h3>
                <p className="text-stone-600 text-sm mb-3 line-clamp-2">{project.description}</p>
                <div className="flex flex-wrap gap-1 mb-3">
                  {project.requiredSkills.slice(0, 3).map((skill) => (
                    <span
                      key={skill}
                      className="inline-block px-2 py-1 bg-amber-100 text-amber-700 text-xs rounded-full"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
                <div className="text-xs text-stone-500">
                  {project.teamSize} members • {project.duration} • {project.location}
                </div>
              </div>
            ))}
          </div>
        </div>
        </div>
      )}
    </div>
  );
}